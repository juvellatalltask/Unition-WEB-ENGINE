var canvas
window.onload=()=>
{
  //when document loads make a canvas
  canvas=document.createElement('canvas')
  document.body.appendChild(canvas)
  cnv=new Canvas(window.innerWidth,window.innerHeight,canvas)
  input=new Input()
  function a()
  {
    ICON.draw(cnv)
    cnv.background('#f0f')
    if(input.key('a'))ICON.x-=0.1
    if(input.key('d'))ICON.x+=0.1
    setTimeout(a)
  }a()
}
//resize canvas to fit window
window.onresize=()=>
{
  cnv.resize(window.innerWidth,window.innerHeight)
}

const DEV_WINDOW_HEIGHT=100
//import image from assets/
function loadImage(path)
{
  img=new Image()
  img.src='assets/'+path
  return img
}
class Sprite
{
  constructor(path,x,y,w,h,center)
  {
    this.img=loadImage(path)
    this.x=x
    this.y=y
    this.w=w
    this.h=h
    this.center=center
  }
  rect()
  {
    r=new Rect(this.x,this.y,this.w,this.h,this.center)
    return r.center?r.get_centered():r
  }
  draw(canvas)
  {
    canvas.blit(this.img,this.x,this.y,this.w,this.h,this.center)
  }
}
class Rect
{
  constructor(x,y,w,h,center)
  {
    this.center=center
    this.x=x
    this.y=y
    this.w=w
    this.h=h
  }
  get_centered()
  {
    return new Rect(
      this.x-this.w/2,
      this.y-this.h/2,
      this.w,this.h,
      false
      )
  }
  collides(rect)
  {
    let a=this.center?this.get_centered():this
    let b=rect.center?rect.get_centered():rect
    return (a.x<b.x+b.w
          &&a.y<b.y+b.h
          &&b.x<a.x+a.w
          &&b.y<a.y+a.h)
  }
  draw(canvas)
  {
    let a=this.center?this.get_centered():this
    canvas.rect(a.x,a.y,a.w,a.h,false)
  }
}
class Vector2
{
  constructor(x=0,y=0)
  {
    this.x=x
    this.y=y
  }
}
class Canvas
{
  constructor(width,height,canvas)
  {
    this.offsetX=0
    this.offsetY=0
    this.width=width
    this.height=height
    this.midX=width/2
    this.midY=height/2
    this.ctx=canvas.getContext('2d')
    canvas.width=this.width
    canvas.height=this.height
    this.elem=canvas
    this.zoom=this.height/DEV_WINDOW_HEIGHT
  }
  background(c)
  {
    this.ctx.fillStyle=c
    this.ctx.fillRect(0,0,this.width,this.height)
  }
  color(c)
  {
    this.ctx.fillStyle=c
  }
  blit(image,x,y,w=0,h=0,center=true)
  {
    this.ctx.drawImage(image,
    (x+this.offsetX-(center?w/2:0))*this.zoom+this.midX,
    (y+this.offsetY-(center?h/2:0))*this.zoom+this.midY,
    w*this.zoom,
    h*this.zoom)
  }
  rect(x,y,w,h,center=false)
  {
    this.ctx.fillRect(
      (x+this.offsetX)*this.zoom+this.midX-(center?w/2:0),
      (y+this.offsetY)*this.zoom+this.midY-(center?h/2:0),
      w*this.zoom,
      h*this.zoom)
  }
  resize(width,height)
  {
    this.width=width
    this.height=height
    this.midX=width/2
    this.midY=height/2
    this.elem.width=width
    this.elem.height=height
    this.zoom=height/DEV_WINDOW_HEIGHT
  }
}
class Input
{
  constructor()
  {
    window.addEventListener('keydown',(e)=>{this.keydown(e)})
    window.addEventListener('keyup',(e)=>{this.keyup(e)})
    this.keys=[]
  }
  key(x)
  {
    return this.keys.indexOf(x)!=-1
  }
  keydown(e)
  {
    let key=e.key
    if(this.keys.indexOf(key)==-1)this.keys.push(key)
  }
  keyup(e)
  {
    let key=e.key
    let io=this.keys.indexOf(key)
    if(io!=-1)this.keys.splice(io,1)
    console.log(this.keys,key)
  }
}
const ICON = new Sprite('icon.png',0,0,100,100,true)